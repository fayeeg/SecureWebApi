Readme

1.Change Connection string

"ConnectionStrings":
{
    "DatabaseConnection": "Data Source=SAI-PC; UID=sa; Password=Pass@123;Database=MoviesDB;"
}

2. Login Credentials

Username :- demo
Username :- 1234567

3. Create Database with name MoviesDB and Run Database  script which is provided.
